
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes, ConversationHandler
from pymongo import MongoClient

# States
(SUBMIT_PHONE, SUBMIT_UPI, SUBMIT_AMOUNT, SUBMIT_PROOF, SUBMIT_PIC, ADMIN_PANEL, ADMIN_REVIEW) = range(7)

# MongoDB setup
MONGO_URI = "mongodb+srv://sji712567:KiJGiv1vroZRPhOw@cluster0.0ew9jzj.mongodb.net/"
client = MongoClient(MONGO_URI)
db = client["scambot"]
scammers_col = db["scammers"]
reports_col = db["reports"]

ADMINS = [1948138813]
USER_TEMP = {}

def scammer_grade(amount):
    if amount >= 10000:
        return "🟥 Ultra Scammer"
    elif amount >= 1000:
        return "🟨 Master Scammer"
    else:
        return "🟩 Chindi Scammer"

def notify_reporter(user_id, msg, app):
    try:
        app.bot.send_message(chat_id=user_id, text=msg)
    except:
        pass

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    keyboard = [
        [InlineKeyboardButton("🔎 Check Scammer", callback_data="check")],
        [InlineKeyboardButton("➕ Submit Scammer Report", callback_data="submit")],
        [InlineKeyboardButton("🛠️ Admin Panel", callback_data="adminpanel")] if user_id in ADMINS else [],
    ]
    keyboard = [k for k in keyboard if k]
    await update.message.reply_text("👋 Welcome to Scammer Buster Bot!", reply_markup=InlineKeyboardMarkup(keyboard))

async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id

    if query.data == "submit":
        USER_TEMP[user_id] = {}
        await context.bot.send_message(chat_id=user_id, text="🔢 Enter scammer's phone number:")
        return SUBMIT_PHONE

    elif query.data == "adminpanel" and user_id in ADMINS:
        pending_count = reports_col.count_documents({"status": "pending"})
        await context.bot.send_message(chat_id=user_id, text=f"🛠️ Admin Panel\nPending reports: {pending_count}",
                                       reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔍 Review Reports", callback_data="reviewreports")]]))
        return ADMIN_PANEL

    elif query.data == "reviewreports" and user_id in ADMINS:
        data = reports_col.find_one({"status": "pending"})
        if not data:
            await context.bot.send_message(chat_id=user_id, text="✅ No pending reports.")
            return ADMIN_PANEL

        context.user_data['current_review'] = data
        await context.bot.send_photo(chat_id=user_id, photo=data["proof"],
                                     caption=f"👤 Phone: {data['phone']}\n💳 UPI: {data['upi']}\n💰 Amount: ₹{data['amount']}\n🎯 Grade: {scammer_grade(data['amount'])}",
                                     reply_markup=InlineKeyboardMarkup([
                                         [InlineKeyboardButton("✅ Approve", callback_data="approve_report"),
                                          InlineKeyboardButton("❌ Reject", callback_data="reject_report")]
                                     ]))
        return ADMIN_REVIEW

    elif query.data in ["approve_report", "reject_report"] and user_id in ADMINS:
        data = context.user_data.get('current_review')
        reports_col.update_one({"_id": data["_id"]}, {"$set": {"status": "approved" if query.data == "approve_report" else "rejected"}})
        if query.data == "approve_report":
            scammers_col.insert_one(data)
            notify_reporter(data["reporter_id"], "✅ Your report has been approved.", context.application)
            await context.bot.send_message(chat_id=user_id, text="👍 Report approved and scammer added.")
        else:
            notify_reporter(data["reporter_id"], "❌ Your report was rejected.", context.application)
            await context.bot.send_message(chat_id=user_id, text="🚫 Report rejected.")
        return await menu_callback(update, context)

async def handle_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    USER_TEMP[user_id]["phone"] = update.message.text.strip()
    await update.message.reply_text("💳 Enter scammer's UPI ID:")
    return SUBMIT_UPI

async def handle_upi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    USER_TEMP[user_id]["upi"] = update.message.text.strip()
    await update.message.reply_text("💰 Enter scam amount:")
    return SUBMIT_AMOUNT

async def handle_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    try:
        amount = int(update.message.text.strip())
        USER_TEMP[user_id]["amount"] = amount
        await update.message.reply_text("📎 Send screenshot or proof of scam (photo):")
        return SUBMIT_PROOF
    except:
        await update.message.reply_text("❌ Please enter a valid number")
        return SUBMIT_AMOUNT

async def handle_proof(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if update.message.photo:
        USER_TEMP[user_id]["proof"] = update.message.photo[-1].file_id
        USER_TEMP[user_id]["reporter_id"] = user_id
        USER_TEMP[user_id]["status"] = "pending"
        reports_col.insert_one(USER_TEMP[user_id])
        await update.message.reply_text("✅ Your report has been submitted for review.")
        for admin_id in ADMINS:
            await context.bot.send_message(chat_id=admin_id, text=f"🚨 New scammer report from user {user_id}")
        return ConversationHandler.END
    else:
        await update.message.reply_text("❌ Please send a valid image.")
        return SUBMIT_PROOF

if __name__ == "__main__":
    app = ApplicationBuilder().token("7887330354:AAGUAJf_GBYGh3DExWecX8B6kd3R8KTBFQ8").build()

    conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(menu_callback, pattern="submit")],
        states={
            SUBMIT_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_phone)],
            SUBMIT_UPI: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_upi)],
            SUBMIT_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_amount)],
            SUBMIT_PROOF: [MessageHandler(filters.PHOTO, handle_proof)],
        },
        fallbacks=[]
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(conv_handler)
    app.add_handler(CallbackQueryHandler(menu_callback))

    print("Bot is running...")
    app.run_polling()
